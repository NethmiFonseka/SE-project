WiCaDi-Calculator

Java Calculator for Graphing and scientific calculator
