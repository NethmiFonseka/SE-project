to open the widget go to WiCaDi/dist/WiCaDi
to open thesource code go to the WiCaDi/src/